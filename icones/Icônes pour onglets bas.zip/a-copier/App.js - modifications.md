# Appliquer la piste « Arène » dans App.js

1. Copier `a-copier/src-components-IconesOnglets.js` vers `FitnessRoyale/src/components/IconesOnglets.js`.
2. Appliquer les 4 modifications ci-dessous dans `FitnessRoyale/App.js`.

Aucune nouvelle dépendance : le fichier d'icônes utilise `react-native-svg`, déjà dans `package.json`.

---

## 1. Import (près de la ligne 35, à côté de `import Losange`)

```js
import { ICONES_ONGLETS } from './src/components/IconesOnglets';
```

`Losange` reste importé : il sert ailleurs dans l'app.

## 2. Table ONGLETS (ligne ~46) — les emojis ne servent plus

```js
const ONGLETS = [
  { cle: 'profil', libelle: 'Profil' },
  { cle: 'perfs', libelle: 'Perfs' },
  { cle: 'paliers', libelle: 'Paliers' },
  { cle: 'competition', libelle: 'Compét.' },
  { cle: 'entrainement', libelle: 'Entraîn.' },
  { cle: 'clan', libelle: 'Clan' },
];
```

Libellés raccourcis : « Compétition » et « Entraînement » passaient à la ligne
et déformaient la hauteur de la barre.

## 3. Rendu de la barre (ligne ~439) — remplacer le bloc `<View style={styles.barreOnglets}>`

```jsx
      {/* Barre d'onglets en bas — piste « Arène » : icône pleine ligne, et sur
          l'onglet actif un liseré or au-dessus + une pastille voilée d'or. */}
      <View style={styles.barreOnglets}>
        {ONGLETS.map((o) => {
          const actif = o.cle === ongletActif;
          const couleur = actif ? colors.or : colors.texteGris;
          const Icone = ICONES_ONGLETS[o.cle];
          return (
            <TouchableOpacity
              key={o.cle}
              style={styles.onglet}
              onPress={() => setOngletActif(o.cle)}
              accessibilityRole="tab"
              accessibilityState={{ selected: actif }}
              accessibilityLabel={o.libelle}
            >
              {actif && <View style={styles.ongletLisere} />}
              <View style={[styles.ongletPastille, actif && styles.ongletPastilleActive]}>
                <Icone taille={20} couleur={couleur} />
              </View>
              <Text style={[styles.ongletLibelle, { color: couleur }]} numberOfLines={1}>
                {o.libelle}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
```

## 4. Styles (ligne ~463) — remplacer `barreOnglets`, `onglet`, `ongletLibelle`

```js
  barreOnglets: {
    flexDirection: 'row',
    backgroundColor: colors.carte,
    borderTopWidth: 1,
    borderTopColor: colors.bordure,
    paddingVertical: 8,
  },
  onglet: { flex: 1, alignItems: 'center', gap: 5 },
  // Liseré or au-dessus de l'onglet actif. Positionné en absolu pour ne pas
  // décaler l'icône : il déborde sur le padding de la barre.
  ongletLisere: {
    position: 'absolute',
    top: -8,
    width: 26,
    height: 2,
    borderRadius: 2,
    backgroundColor: colors.or,
  },
  ongletPastille: {
    width: 34,
    height: 26,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ongletPastilleActive: { backgroundColor: 'rgba(232, 178, 58, 0.08)' },
  ongletLibelle: { fontSize: 10.5, fontWeight: '800', letterSpacing: 0.5 },
```

Si `colors.or` n'est pas exactement `#E8B23A`, ajuster le `rgba(...)` de
`ongletPastilleActive` en conséquence (même teinte, 8 % d'opacité).
